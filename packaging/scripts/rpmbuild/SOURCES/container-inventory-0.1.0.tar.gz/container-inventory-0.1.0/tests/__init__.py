"""
Tests for Container Inventory package.
"""
